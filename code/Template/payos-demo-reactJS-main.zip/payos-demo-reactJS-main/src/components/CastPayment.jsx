
const CastPayment = () => {

}

export default CastPayment;