<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>PHP Exercises</title>
</head>
<body>
<div class="container">

    <div class="row">
        <div class="col-md-6 my-5 mx-auto border rounded px-3 py-3">
            <h6 class="text-center mb-3">Gợi ý tên quốc gia</h6>
            <input oninput="suggest(this.value)" id="countryInput" type="text" class="form-control" placeholder="Nhập ít nhất 2 ký tự">
            <ul id="suggestions" class="list-group my-2"></ul>
        </div>
    </div>
</div>

<script>
        function suggest(query) {
            if (query.length >= 2) {
                $.ajax({
                    url: 'suggest.php',
                    type: 'POST',
                    data: { query: query },
                    dataType: 'json',
                    success: function(data) {
                        var suggestions = $('#suggestions');
                        suggestions.empty();
                        if (data.length > 0) {
                            $.each(data, function(i, country){
                                suggestions.append('<li class="list-group-item">' + country + '</li>');
                            });
                        } else {
                            suggestions.append('<li class="list-group-item text-muted">Không tìm thấy</li>');
                        }
                    }
                });
            } else {
                $('#suggestions').empty();
            }
        }

        $(document).on('click', '#suggestions li', function(){
            $('#countryInput').val($(this).text());
            $('#suggestions').empty();
        });

</script>

</body>
</html>
